import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import {
  Mail,
  Phone,
  MapPin,
  Github,
  Linkedin,
  Download,
  Code,
  Zap,
  Database,
  BarChart3,
  Workflow,
  Globe,
} from "lucide-react"

export default function Portfolio() {
  const skills = [
    "Power Apps",
    "Power Automate",
    "Power BI",
    "PCF",
    "Microsoft Graph API",
    "n8n",
    "Bubble",
    "Supabase",
    "SharePoint",
    "OAuth2",
    "REST APIs",
  ]

  const projects = [
    {
      name: "Employee Onboarding Automation",
      description:
        "Complete automation workflow using Power Automate and SharePoint for new employee setup, including account creation, equipment assignment, and training scheduling.",
      technologies: ["Power Automate", "SharePoint", "Microsoft Graph", "Power Apps"],
      icon: <Workflow className="w-6 h-6" />,
    },
    {
      name: "Sales Dashboard & Analytics",
      description:
        "Interactive Power BI dashboard with real-time sales metrics, forecasting, and automated reporting for executive team decision making.",
      technologies: ["Power BI", "Power Automate", "SharePoint", "Excel"],
      icon: <BarChart3 className="w-6 h-6" />,
    },
    {
      name: "Approval Management System",
      description:
        "Custom Power Apps solution for multi-level approval workflows with automated notifications and audit trails using Supabase backend.",
      technologies: ["Power Apps", "Supabase", "Power Automate", "PCF"],
      icon: <Code className="w-6 h-6" />,
    },
    {
      name: "Customer Portal Integration",
      description:
        "Bubble-based customer portal with n8n automation for order processing, support tickets, and real-time status updates via Microsoft Graph.",
      technologies: ["Bubble", "n8n", "Microsoft Graph", "REST APIs"],
      icon: <Globe className="w-6 h-6" />,
    },
    {
      name: "Data Migration & Sync Tool",
      description:
        "Automated data synchronization between legacy systems and modern cloud platforms using n8n workflows and OAuth2 authentication.",
      technologies: ["n8n", "OAuth2", "REST APIs", "Supabase"],
      icon: <Database className="w-6 h-6" />,
    },
    {
      name: "Business Process Optimizer",
      description:
        "End-to-end automation solution that reduced manual processing time by 80% using Power Platform and custom connectors.",
      technologies: ["Power Apps", "Power Automate", "PCF", "Microsoft Graph"],
      icon: <Zap className="w-6 h-6" />,
    },
  ]

  return (
    <div className="min-h-screen bg-white">
      {/* Header */}
      <header className="border-b border-gray-100 sticky top-0 bg-white/95 backdrop-blur-sm z-50">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Guilherme Santi Clair</h1>
              <p className="text-[#0078D4] font-medium">Low-Code Developer & Automation Architect</p>
            </div>
            <nav className="hidden md:flex space-x-8">
              <a href="#about" className="text-gray-600 hover:text-[#0078D4] transition-colors">
                About
              </a>
              <a href="#skills" className="text-gray-600 hover:text-[#0078D4] transition-colors">
                Skills
              </a>
              <a href="#projects" className="text-gray-600 hover:text-[#0078D4] transition-colors">
                Projects
              </a>
              <a href="#contact" className="text-gray-600 hover:text-[#0078D4] transition-colors">
                Contact
              </a>
            </nav>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section id="about" className="py-20 bg-gradient-to-br from-blue-50 to-white">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="w-32 h-32 bg-[#0078D4] rounded-full mx-auto mb-8 flex items-center justify-center">
              <span className="text-white text-4xl font-bold">GS</span>
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
              Building the Future with
              <span className="text-[#0078D4]"> Low-Code</span>
            </h2>
            <p className="text-xl text-gray-600 mb-8 leading-relaxed">
              I build powerful automations and business apps using Power Platform, Bubble, n8n, Supabase, and Microsoft
              Graph. From dashboards to approval apps, I deliver real business impact with low-code.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-[#0078D4] hover:bg-[#106ebe] text-white">
                <Mail className="w-4 h-4 mr-2" />
                Get In Touch
              </Button>
              <Button
                variant="outline"
                size="lg"
                className="border-[#0078D4] text-[#0078D4] hover:bg-[#0078D4] hover:text-white bg-transparent"
              >
                <Download className="w-4 h-4 mr-2" />
                Download CV
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Skills Section */}
      <section id="skills" className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Technical Expertise</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
              {skills.map((skill, index) => (
                <div key={index} className="group">
                  <Badge
                    variant="secondary"
                    className="w-full justify-center py-3 px-4 text-sm font-medium bg-gray-50 text-gray-700 hover:bg-[#0078D4] hover:text-white transition-colors cursor-default"
                  >
                    {skill}
                  </Badge>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Projects Section */}
      <section id="projects" className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-6xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Featured Projects</h2>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {projects.map((project, index) => (
                <Card key={index} className="group hover:shadow-lg transition-shadow duration-300 border-0 shadow-sm">
                  <CardHeader>
                    <div className="flex items-center gap-3 mb-2">
                      <div className="p-2 bg-[#0078D4]/10 rounded-lg text-[#0078D4] group-hover:bg-[#0078D4] group-hover:text-white transition-colors">
                        {project.icon}
                      </div>
                      <CardTitle className="text-lg">{project.name}</CardTitle>
                    </div>
                    <CardDescription className="text-gray-600 leading-relaxed">{project.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="flex flex-wrap gap-2">
                      {project.technologies.map((tech, techIndex) => (
                        <Badge key={techIndex} variant="outline" className="text-xs border-[#0078D4]/30 text-[#0078D4]">
                          {tech}
                        </Badge>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <h2 className="text-3xl font-bold text-center text-gray-900 mb-12">Let's Work Together</h2>
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-xl font-semibold text-gray-900 mb-6">Get in touch</h3>
                <p className="text-gray-600 mb-8 leading-relaxed">
                  Ready to automate your business processes or build custom applications? Let's discuss how low-code
                  solutions can transform your operations.
                </p>
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Mail className="w-5 h-5 text-[#0078D4]" />
                    <span className="text-gray-600">guilherme@example.com</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Phone className="w-5 h-5 text-[#0078D4]" />
                    <span className="text-gray-600">+55 (11) 99999-9999</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <MapPin className="w-5 h-5 text-[#0078D4]" />
                    <span className="text-gray-600">São Paulo, Brazil</span>
                  </div>
                </div>
              </div>
              <Card className="border-0 shadow-sm">
                <CardContent className="p-6">
                  <form className="space-y-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-700 mb-2">
                        Name
                      </label>
                      <Input
                        id="name"
                        placeholder="Your name"
                        className="border-gray-200 focus:border-[#0078D4] focus:ring-[#0078D4]"
                      />
                    </div>
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-2">
                        Email
                      </label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="your.email@example.com"
                        className="border-gray-200 focus:border-[#0078D4] focus:ring-[#0078D4]"
                      />
                    </div>
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-700 mb-2">
                        Message
                      </label>
                      <Textarea
                        id="message"
                        placeholder="Tell me about your project..."
                        rows={4}
                        className="border-gray-200 focus:border-[#0078D4] focus:ring-[#0078D4]"
                      />
                    </div>
                    <Button type="submit" className="w-full bg-[#0078D4] hover:bg-[#106ebe] text-white">
                      Send Message
                    </Button>
                  </form>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-6 md:mb-0">
                <h3 className="text-xl font-bold mb-2">Guilherme Santi Clair</h3>
                <p className="text-gray-400">Low-Code Developer & Automation Architect</p>
              </div>
              <div className="flex space-x-6">
                <a
                  href="https://github.com"
                  className="text-gray-400 hover:text-white transition-colors"
                  aria-label="GitHub"
                >
                  <Github className="w-6 h-6" />
                </a>
                <a
                  href="https://linkedin.com"
                  className="text-gray-400 hover:text-white transition-colors"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="w-6 h-6" />
                </a>
                <a href="/cv.pdf" className="text-gray-400 hover:text-white transition-colors" aria-label="Download CV">
                  <Download className="w-6 h-6" />
                </a>
              </div>
            </div>
            <div className="border-t border-gray-800 mt-8 pt-8 text-center">
              <p className="text-gray-400 text-sm">
                © {new Date().getFullYear()} Guilherme Santi Clair. All rights reserved.
              </p>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
